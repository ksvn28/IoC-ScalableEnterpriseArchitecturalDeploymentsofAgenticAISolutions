import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Activity, Bot, GitBranch, LayoutDashboard, Menu, Orbit, Radio, Rocket, ScrollText, ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const nav = [
  { to: "/", label: "Overview", icon: LayoutDashboard },
  { to: "/agents", label: "Agents", icon: Bot },
  { to: "/workflows", label: "Workflows", icon: GitBranch },
  { to: "/security", label: "Security", icon: ShieldCheck },
  { to: "/deployments", label: "Deployments", icon: Rocket },
  { to: "/logs", label: "Logs & Traces", icon: ScrollText },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="starfield min-h-screen overflow-hidden bg-background text-foreground">
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 border-r border-sidebar-border bg-sidebar backdrop-blur-xl transition-transform lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-5">
          <span className="relative grid h-9 w-9 place-items-center border border-primary/50 bg-primary/10 text-primary shadow-[0_0_18px_var(--primary)]"><Orbit className="h-5 w-5" /><span className="absolute h-1.5 w-1.5 rounded-full bg-warning right-0 top-0" /></span>
          <div><span className="block font-mono text-sm font-bold uppercase">AgentOps</span><span className="block font-mono text-[9px] uppercase text-primary/70">Mission console</span></div>
          <Button variant="ghost" size="icon" className="ml-auto lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="px-5 pt-6 font-mono text-[9px] uppercase text-primary/60">Core systems // 06</div>
        <nav className="space-y-1 p-3">
          {nav.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              onClick={() => setOpen(false)}
              activeOptions={{ exact: to === "/" }}
              className="group flex items-center gap-3 border-l-2 border-transparent px-3 py-2.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground"
              activeProps={{ className: "border-primary bg-sidebar-accent text-sidebar-accent-foreground font-medium shadow-[inset_12px_0_20px_-18px_var(--primary)]" }}
            >
              <span className="grid h-7 w-7 place-items-center border border-sidebar-border bg-background/40 text-primary/70 group-hover:shadow-[0_0_12px_var(--primary)]"><Icon className="h-4 w-4" /></span>
              {label}
            </Link>
          ))}
        </nav>
        <div className="absolute bottom-0 w-full border-t border-sidebar-border p-4 text-xs text-muted-foreground">
          <div className="instrument-panel border border-sidebar-border bg-background/40 p-3">
            <div className="mb-2 flex items-center justify-between font-mono text-[9px] uppercase"><span>Signal strength</span><span className="text-primary">98.4%</span></div>
            <div className="h-1 overflow-hidden bg-muted"><div className="h-full w-[98%] bg-primary shadow-[0_0_9px_var(--primary)]" /></div>
            <div className="mt-3 flex items-center gap-2 text-[10px] text-success"><Radio className="h-3 w-3" /> Systems nominal</div>
          </div>
        </div>
      </aside>
      {open && <div className="fixed inset-0 z-30 bg-background/70 lg:hidden" onClick={() => setOpen(false)} />}
      <div className="relative z-10 lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-xl lg:px-8">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </Button>
          <span className="border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[10px] text-primary">SYS_LINK: ACTIVE</span>
          <span className="hidden text-sm text-muted-foreground sm:inline">org / acme-prod</span>
          <span className="ml-auto border border-border bg-card px-2.5 py-1 font-mono text-[10px] text-muted-foreground">SECTOR · us-east-1</span>
        </header>
        <main className="relative min-h-[calc(100vh-4rem)] p-4 pb-12 lg:p-8 lg:pb-12">{children}</main>
        <footer className="fixed bottom-0 right-0 z-20 hidden h-6 items-center justify-between border-t border-border bg-background/85 px-6 font-mono text-[9px] text-muted-foreground backdrop-blur lg:left-64 lg:flex"><span className="text-success">● SYSTEMS NOMINAL · LAT 42MS</span><span>BUILD 4.2.0 · AGENTOPS CONSOLE</span></footer>
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-7">
      <div className="mb-1 font-mono text-[10px] uppercase text-primary">[ Authenticated: Operator ]</div>
      <h1 className="text-2xl font-bold uppercase">{title}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
    </div>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`instrument-panel rounded-md border border-border bg-card backdrop-blur-md transition-colors hover:border-primary/60 ${className}`}>{children}</div>;
}

const tones: Record<string, string> = {
  success: "animate-pulse bg-success/15 text-success border-success/40 shadow-[0_0_12px_var(--success)]",
  warning: "bg-warning/15 text-warning border-warning/30",
  danger: "alert-flash bg-destructive/15 text-destructive border-destructive/40 shadow-[0_0_12px_var(--destructive)]",
  info: "bg-info/15 text-info border-info/30",
  muted: "bg-muted text-muted-foreground border-border",
};
export function Pill({ tone, children }: { tone: keyof typeof tones | string; children: ReactNode }) {
  return <span className={`inline-flex items-center border px-2 py-0.5 font-mono text-[10px] uppercase ${tones[tone] ?? tones["muted"]}`}>{children}</span>;
}
