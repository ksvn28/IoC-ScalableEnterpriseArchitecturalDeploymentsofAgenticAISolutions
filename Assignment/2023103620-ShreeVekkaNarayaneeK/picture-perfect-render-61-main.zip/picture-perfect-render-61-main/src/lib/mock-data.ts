export type AgentStatus = "Running" | "Idle" | "Failed";
export const agents = [
  { id: "ag-01", name: "invoice-extractor", type: "Document AI", status: "Running" as AgentStatus, uptime: "14d 6h", lastPing: "2s ago", model: "gpt-5-mini", region: "us-east-1", tasks: 18234, errorRate: "0.4%" },
  { id: "ag-02", name: "support-triage", type: "Conversational", status: "Running" as AgentStatus, uptime: "9d 2h", lastPing: "1s ago", model: "gemini-2.5-flash", region: "us-east-1", tasks: 40211, errorRate: "0.9%" },
  { id: "ag-03", name: "code-reviewer", type: "Dev Tools", status: "Idle" as AgentStatus, uptime: "3d 11h", lastPing: "4m ago", model: "gpt-5", region: "eu-west-1", tasks: 1288, errorRate: "1.2%" },
  { id: "ag-04", name: "fraud-sentinel", type: "Risk", status: "Running" as AgentStatus, uptime: "31d 0h", lastPing: "3s ago", model: "custom-xgb+llm", region: "us-west-2", tasks: 902114, errorRate: "0.1%" },
  { id: "ag-05", name: "crm-enricher", type: "Data Pipeline", status: "Failed" as AgentStatus, uptime: "0h 0m", lastPing: "27m ago", model: "gpt-5-mini", region: "us-east-1", tasks: 5530, errorRate: "12.6%" },
  { id: "ag-06", name: "contract-summarizer", type: "Document AI", status: "Idle" as AgentStatus, uptime: "6d 19h", lastPing: "12m ago", model: "gemini-2.5-pro", region: "eu-west-1", tasks: 742, errorRate: "0.7%" },
  { id: "ag-07", name: "sales-outreach", type: "Conversational", status: "Running" as AgentStatus, uptime: "2d 4h", lastPing: "5s ago", model: "gpt-5", region: "us-east-1", tasks: 3109, errorRate: "2.1%" },
  { id: "ag-08", name: "inventory-forecaster", type: "Analytics", status: "Running" as AgentStatus, uptime: "21d 8h", lastPing: "9s ago", model: "custom-prophet", region: "ap-south-1", tasks: 64120, errorRate: "0.3%" },
];

export const activity = [
  { day: "Sep 25", tasks: 8120, errors: 92 },
  { day: "Sep 26", tasks: 9340, errors: 110 },
  { day: "Sep 27", tasks: 7810, errors: 64 },
  { day: "Sep 28", tasks: 6420, errors: 51 },
  { day: "Sep 29", tasks: 10230, errors: 133 },
  { day: "Sep 30", tasks: 11890, errors: 147 },
  { day: "Oct 1", tasks: 12640, errors: 121 },
];

export const events = [
  { time: "17:21:04", text: "crm-enricher crashed: upstream 503 from Salesforce", tone: "danger" },
  { time: "17:18:40", text: "Workflow 'Q4 churn scoring' moved to Review", tone: "info" },
  { time: "17:12:09", text: "Canary v2.14.0 at 25% traffic — healthy", tone: "success" },
  { time: "17:05:55", text: "Rate limit warning on support-triage (82% quota)", tone: "warning" },
  { time: "16:58:13", text: "New API key issued for team data-platform", tone: "info" },
  { time: "16:44:30", text: "fraud-sentinel flagged 14 transactions", tone: "warning" },
  { time: "16:30:02", text: "Staging deploy v2.14.0 passed 412 tests", tone: "success" },
  { time: "16:11:47", text: "code-reviewer went idle (no queue)", tone: "muted" },
];

export type Priority = "High" | "Medium" | "Low";
export const workflows: Record<string, { name: string; agent: string; priority: Priority }[]> = {
  Queued: [
    { name: "Nightly invoice batch", agent: "invoice-extractor", priority: "Medium" },
    { name: "EU contract renewals", agent: "contract-summarizer", priority: "Low" },
    { name: "Lead enrichment backfill", agent: "crm-enricher", priority: "High" },
  ],
  Running: [
    { name: "Ticket auto-routing", agent: "support-triage", priority: "High" },
    { name: "Card-not-present screening", agent: "fraud-sentinel", priority: "High" },
    { name: "Holiday demand forecast", agent: "inventory-forecaster", priority: "Medium" },
  ],
  Review: [
    { name: "Q4 churn scoring", agent: "sales-outreach", priority: "Medium" },
    { name: "PR #4821 review", agent: "code-reviewer", priority: "Low" },
  ],
  Done: [
    { name: "Vendor onboarding docs", agent: "invoice-extractor", priority: "Low" },
    { name: "Chargeback analysis", agent: "fraud-sentinel", priority: "Medium" },
  ],
};

export type Severity = "Critical" | "High" | "Medium" | "Low";
export const securityEvents = [
  { time: "2026-10-01 17:09", event: "Prompt injection attempt blocked", source: "support-triage", severity: "Critical" as Severity },
  { time: "2026-10-01 16:52", event: "5 failed logins from 185.220.101.4", source: "auth-gateway", severity: "High" as Severity },
  { time: "2026-10-01 16:20", event: "Agent requested out-of-scope tool: shell.exec", source: "code-reviewer", severity: "High" as Severity },
  { time: "2026-10-01 15:47", event: "API key used from new region", source: "data-platform", severity: "Medium" as Severity },
  { time: "2026-10-01 14:03", event: "PII redaction applied to 31 outputs", source: "contract-summarizer", severity: "Low" as Severity },
  { time: "2026-10-01 12:38", event: "TLS certificate renews in 14 days", source: "edge-proxy", severity: "Low" as Severity },
];

export const environments = [
  { name: "Dev", version: "v2.15.0-rc1", health: "Healthy", instances: 2, updated: "8m ago" },
  { name: "Staging", version: "v2.14.0", health: "Healthy", instances: 4, updated: "1h ago" },
  { name: "Canary", version: "v2.14.0", health: "Degraded", instances: 2, updated: "22m ago", note: "25% traffic · p95 +40ms" },
  { name: "Production", version: "v2.13.2", health: "Healthy", instances: 24, updated: "3d ago" },
];

export type Level = "INFO" | "WARN" | "ERROR" | "DEBUG";
const srcs = agents.map((a) => a.name);
const msgs: [Level, string][] = [
  ["INFO", "task completed in 842ms (tokens=1,204)"],
  ["DEBUG", "tool_call search_kb args={query:'refund policy'}"],
  ["INFO", "trace 7f3a…c21 span=llm.generate duration=611ms"],
  ["WARN", "retrying upstream request (attempt 2/3)"],
  ["ERROR", "HTTP 503 from api.salesforce.com — circuit open"],
  ["INFO", "heartbeat ok"],
  ["DEBUG", "cache hit embeddings:invoice#8821"],
  ["WARN", "token budget at 82% for tenant acme"],
  ["INFO", "workflow step 3/5 'validate' passed"],
  ["ERROR", "schema validation failed: field 'amount' missing"],
];
export const logs = Array.from({ length: 80 }, (_, i) => {
  const [level, msg] = msgs[(i * 7) % msgs.length]!;
  const s = 59 - (i % 60);
  return { id: i, ts: `17:${String(21 - Math.floor(i / 6)).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String((i * 137) % 1000).padStart(3, "0")}`, level, source: srcs[(i * 3) % srcs.length]!, msg };
});
