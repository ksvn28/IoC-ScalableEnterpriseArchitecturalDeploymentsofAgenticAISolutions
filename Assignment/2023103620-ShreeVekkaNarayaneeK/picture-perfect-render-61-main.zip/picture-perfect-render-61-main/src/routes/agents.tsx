import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MoreHorizontal, X } from "lucide-react";
import { PageHeader, Panel, Pill } from "@/components/app-shell";
import { agents } from "@/lib/mock-data";

export const Route = createFileRoute("/agents")({
  head: () => ({
    meta: [
      { title: "Agents — AgentOps Console" },
      { name: "description", content: "Status, uptime and details for every deployed agent." },
      { property: "og:title", content: "Agents — AgentOps Console" },
      { property: "og:description", content: "Status, uptime and details for every deployed agent." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Agents,
});

const tone = { Running: "success", Idle: "muted", Failed: "danger" } as const;

function Agents() {
  const [sel, setSel] = useState<(typeof agents)[number] | null>(null);
  return (
    <>
      <PageHeader title="Agents" subtitle={`${agents.length} agents deployed`} />
      <Panel className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>{["Agent Name", "Type", "Status", "Uptime", "Last Ping", "Actions"].map((h) => <th key={h} className="px-5 py-3 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {agents.map((a) => (
              <tr key={a.id} onClick={() => setSel(a)} className="cursor-pointer border-b border-border last:border-0 transition-colors hover:bg-accent">
                <td className="px-5 py-3 font-mono"><span className="inline-flex items-center gap-3"><span className={`relative grid h-7 w-7 place-items-center rounded-full border ${a.status === "Running" ? "border-success/60 text-success" : a.status === "Failed" ? "alert-flash border-destructive/60 text-destructive" : "border-muted-foreground/30 text-muted-foreground"}`}><span className="h-2 w-2 rounded-full bg-current" />{a.status === "Running" && <span className="orbit-ring absolute -inset-1 rounded-full border border-dashed border-current" />}</span>{a.name}</span></td>
                <td className="px-5 py-3 text-muted-foreground">{a.type}</td>
                <td className="px-5 py-3"><Pill tone={tone[a.status]}>{a.status}</Pill></td>
                <td className="px-5 py-3">{a.uptime}</td>
                <td className="px-5 py-3 text-muted-foreground">{a.lastPing}</td>
                <td className="px-5 py-3"><MoreHorizontal className="h-4 w-4 text-muted-foreground" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      {sel && (
        <>
          <div className="fixed inset-0 z-40 bg-background/70" onClick={() => setSel(null)} />
          <aside className="fixed inset-y-0 right-0 z-50 w-full max-w-md overflow-y-auto border-l border-border bg-card p-6 animate-in slide-in-from-right">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-mono text-lg font-semibold">{sel.name}</h2>
                <p className="text-sm text-muted-foreground">{sel.type}</p>
              </div>
              <button onClick={() => setSel(null)} aria-label="Close"><X className="h-5 w-5" /></button>
            </div>
            <div className="mt-4"><Pill tone={tone[sel.status]}>{sel.status}</Pill></div>
            <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
              {[["Agent ID", sel.id], ["Model", sel.model], ["Region", sel.region], ["Uptime", sel.uptime], ["Last ping", sel.lastPing], ["Tasks (30d)", sel.tasks.toLocaleString()], ["Error rate", sel.errorRate]].map(([k, v]) => (
                <div key={k} className="rounded-md border border-border p-3">
                  <dt className="text-xs text-muted-foreground">{k}</dt>
                  <dd className="mt-1 font-medium">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-6 flex gap-2">
              <button className="rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">Restart</button>
              <button className="rounded-md border border-border px-3 py-2 text-sm hover:bg-accent">View logs</button>
            </div>
          </aside>
        </>
      )}
    </>
  );
}
