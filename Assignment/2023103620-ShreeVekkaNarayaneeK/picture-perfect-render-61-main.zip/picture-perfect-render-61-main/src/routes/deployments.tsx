import { createFileRoute } from "@tanstack/react-router";
import { ChevronRight, Rocket } from "lucide-react";
import { Fragment } from "react";
import { PageHeader, Panel } from "@/components/app-shell";
import { environments } from "@/lib/mock-data";

export const Route = createFileRoute("/deployments")({
  head: () => ({
    meta: [
      { title: "Deployments — AgentOps Console" },
      { name: "description", content: "Release pipeline from Dev to Production with environment health." },
      { property: "og:title", content: "Deployments — AgentOps Console" },
      { property: "og:description", content: "Release pipeline from Dev to Production with environment health." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Deployments,
});

const hDot: Record<string, string> = { Healthy: "bg-success", Degraded: "bg-warning", Down: "bg-destructive" };

function Deployments() {
  return (
    <>
      <PageHeader title="Deployments" subtitle="Dev → Staging → Canary → Production" />
      <div className="relative mb-6 hidden h-16 items-center md:flex" aria-hidden="true"><div className="absolute left-4 right-4 h-px bg-border" /><div className="absolute left-[64%] h-px w-[12%] bg-warning shadow-[0_0_12px_var(--warning)]" /><Rocket className="absolute left-[72%] h-7 w-7 rotate-45 text-warning drop-shadow-[0_0_8px_var(--warning)]" />{environments.map((e) => <span key={e.name} className="relative z-10 mx-auto h-3 w-3 rounded-full border border-primary bg-background shadow-[0_0_10px_var(--primary)]" />)}</div>
      <div className="flex flex-col gap-3 lg:flex-row lg:items-stretch">
        {environments.map((e, i) => (
          <Fragment key={e.name}>
            <Panel className="flex-1 p-5">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wide text-muted-foreground">Step {i + 1}</span>
                <span className="flex items-center gap-2 text-xs">
                  <span className={`h-2.5 w-2.5 rounded-full ${hDot[e.health]} ${e.health !== "Healthy" ? "animate-pulse" : ""}`} />{e.health}
                </span>
              </div>
              <div className="mt-3 text-lg font-semibold">{e.name}</div>
              <div className="font-mono text-sm text-primary">{e.version}</div>
              <div className="mt-4 space-y-1 text-xs text-muted-foreground">
                <div>{e.instances} instances</div>
                <div>Updated {e.updated}</div>
                {e.note && <div className="text-warning">{e.note}</div>}
              </div>
            </Panel>
            {i < environments.length - 1 && <ChevronRight className="mx-auto h-5 w-5 rotate-90 self-center text-muted-foreground lg:rotate-0" />}
          </Fragment>
        ))}
      </div>
    </>
  );
}
