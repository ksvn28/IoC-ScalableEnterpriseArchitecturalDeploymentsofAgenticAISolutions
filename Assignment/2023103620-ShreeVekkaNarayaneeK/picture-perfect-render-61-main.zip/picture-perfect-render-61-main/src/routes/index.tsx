import { createFileRoute } from "@tanstack/react-router";
import { Bot, GitBranch, Orbit, ShieldAlert, Timer } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { PageHeader, Panel } from "@/components/app-shell";
import { activity, events } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Overview — AgentOps Console" },
      { name: "description", content: "Fleet-wide KPIs, 7-day agent activity, and live events." },
      { property: "og:title", content: "Overview — AgentOps Console" },
      { property: "og:description", content: "Fleet-wide KPIs, 7-day agent activity, and live events." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Overview,
});

const kpis = [
  { label: "Total Agents", value: "48", delta: "+3 this week", icon: Bot },
  { label: "Active Workflows", value: "126", delta: "+12% vs last week", icon: GitBranch },
  { label: "Security Alerts", value: "7", delta: "2 critical", icon: ShieldAlert },
  { label: "Avg Response Time", value: "842ms", delta: "−6% vs last week", icon: Timer },
];

const dot: Record<string, string> = { danger: "bg-destructive", info: "bg-info", success: "bg-success", warning: "bg-warning", muted: "bg-muted-foreground" };

function Overview() {
  return (
    <>
      <div className="planet-turn pointer-events-none absolute right-[-10%] top-[-6rem] -z-10 h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle_at_35%_30%,var(--primary),var(--chart-1)_24%,var(--warning)_52%,transparent_71%)] opacity-20 blur-[2px] shadow-[0_0_100px_var(--primary)]" aria-hidden="true"><span className="absolute -inset-12 rounded-full border border-primary/20" /><span className="absolute -inset-24 rounded-full border border-primary/10" /></div>
      <PageHeader title="Overview" subtitle="Health of your deployed agent fleet" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map(({ label, value, delta, icon: Icon }) => (
          <Panel key={label} className="group relative overflow-hidden p-5">
            <span className="absolute right-2 top-2 h-5 w-5 border-r border-t border-primary/30 transition-colors group-hover:border-primary" />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              {label}
              <Icon className="h-4 w-4 text-primary" />
            </div>
            <div className="mt-3 text-3xl font-semibold tracking-tight">{value}</div>
            <div className="mt-1 text-xs text-muted-foreground">{delta}</div>
          </Panel>
        ))}
      </div>
      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Panel className="p-5 xl:col-span-2">
          <h2 className="text-sm font-medium">Agent activity · last 7 days</h2>
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activity}>
                <defs><linearGradient id="missionGradient" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="var(--chart-1)" /><stop offset="55%" stopColor="var(--chart-2)" /><stop offset="100%" stopColor="var(--chart-3)" /></linearGradient></defs>
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="tasks" name="Tasks" stroke="url(#missionGradient)" strokeWidth={3} dot={false} />
                <Line type="monotone" dataKey="errors" name="Errors" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel className="p-5">
          <h2 className="flex items-center gap-2 text-sm font-medium"><Orbit className="h-4 w-4 text-primary" />Orbital events</h2>
          <ul className="mt-4 space-y-4">
            {events.map((e) => (
              <li key={e.time} className="flex gap-3">
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${dot[e.tone]}`} />
                <div>
                  <div className="font-mono text-xs text-muted-foreground">{e.time}</div>
                  <div className="text-sm">{e.text}</div>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </>
  );
}
