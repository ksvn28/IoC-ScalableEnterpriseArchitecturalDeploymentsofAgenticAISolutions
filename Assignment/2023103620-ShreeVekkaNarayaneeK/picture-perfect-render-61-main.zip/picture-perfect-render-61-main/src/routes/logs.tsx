import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { PageHeader, Panel } from "@/components/app-shell";
import { logs, type Level } from "@/lib/mock-data";

export const Route = createFileRoute("/logs")({
  head: () => ({
    meta: [
      { title: "Logs & Traces — AgentOps Console" },
      { name: "description", content: "Search and filter agent logs and traces by level." },
      { property: "og:title", content: "Logs & Traces — AgentOps Console" },
      { property: "og:description", content: "Search and filter agent logs and traces by level." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Logs,
});

const lvl: Record<Level, string> = { INFO: "text-info", WARN: "text-warning", ERROR: "text-destructive", DEBUG: "text-muted-foreground" };

function Logs() {
  const [q, setQ] = useState("");
  const [level, setLevel] = useState<"ALL" | Level>("ALL");
  const rows = useMemo(
    () => logs.filter((l) => (level === "ALL" || l.level === level) && (l.msg + l.source).toLowerCase().includes(q.toLowerCase())),
    [q, level],
  );
  return (
    <>
      <PageHeader title="Logs & Traces" subtitle="Live stream across all agents" />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <label className="flex flex-1 items-center gap-2 rounded-md border border-input bg-card px-3 focus-within:border-ring">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search messages or agents…" className="h-10 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
        </label>
        <select value={level} onChange={(e) => setLevel(e.target.value as "ALL" | Level)} className="h-10 rounded-md border border-input bg-card px-3 text-sm outline-none focus:border-ring">
          {["ALL", "INFO", "WARN", "ERROR", "DEBUG"].map((l) => <option key={l}>{l}</option>)}
        </select>
      </div>
      <Panel className="h-[65vh] overflow-auto p-2 font-mono text-xs">
        {rows.length === 0 && <div className="p-4 text-muted-foreground">No matching logs.</div>}
        {rows.map((l) => (
          <div key={l.id} className="flex gap-3 whitespace-nowrap rounded px-2 py-1 hover:bg-accent">
            <span className="text-muted-foreground">{l.ts}</span>
            <span className={`w-12 font-semibold ${lvl[l.level]}`}>{l.level}</span>
            <span className="text-primary">{l.source}</span>
            <span>{l.msg}</span>
          </div>
        ))}
      </Panel>
    </>
  );
}
