import { createFileRoute } from "@tanstack/react-router";
import { KeyRound, ShieldAlert, Users } from "lucide-react";
import { PageHeader, Panel, Pill } from "@/components/app-shell";
import { securityEvents } from "@/lib/mock-data";

export const Route = createFileRoute("/security")({
  head: () => ({
    meta: [
      { title: "Security — AgentOps Console" },
      { name: "description", content: "Sessions, failed authentications and security events across agents." },
      { property: "og:title", content: "Security — AgentOps Console" },
      { property: "og:description", content: "Sessions, failed authentications and security events across agents." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Security,
});

const sTone = { Critical: "danger", High: "warning", Medium: "info", Low: "muted" } as const;
const cards = [
  { label: "Active Sessions", value: "312", icon: Users },
  { label: "Failed Auths (24h)", value: "27", icon: KeyRound },
  { label: "Open Alerts", value: "7", icon: ShieldAlert },
];

function Security() {
  return (
    <>
      <PageHeader title="Security" subtitle="Access, authentication and threat signals" />
      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map(({ label, value, icon: Icon }) => (
          <Panel key={label} className="p-5">
            <div className="flex items-center justify-between text-sm text-muted-foreground">{label}<Icon className="h-4 w-4 text-primary" /></div>
            <div className="mt-3 text-3xl font-semibold">{value}</div>
          </Panel>
        ))}
      </div>
      <Panel className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>{["Time", "Event", "Source", "Severity"].map((h) => <th key={h} className="px-5 py-3 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {securityEvents.map((e) => (
              <tr key={e.time} className="border-b border-border last:border-0 hover:bg-accent">
                <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{e.time}</td>
                <td className="px-5 py-3">{e.event}</td>
                <td className="px-5 py-3 font-mono text-muted-foreground">{e.source}</td>
                <td className="px-5 py-3"><Pill tone={sTone[e.severity]}>{e.severity}</Pill></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </>
  );
}
