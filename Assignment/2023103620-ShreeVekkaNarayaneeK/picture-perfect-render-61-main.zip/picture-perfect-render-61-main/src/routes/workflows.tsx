import { createFileRoute } from "@tanstack/react-router";
import { Bot } from "lucide-react";
import { PageHeader, Panel, Pill } from "@/components/app-shell";
import { workflows } from "@/lib/mock-data";

export const Route = createFileRoute("/workflows")({
  head: () => ({
    meta: [
      { title: "Workflows — AgentOps Console" },
      { name: "description", content: "Kanban board of queued, running and completed agent workflows." },
      { property: "og:title", content: "Workflows — AgentOps Console" },
      { property: "og:description", content: "Kanban board of queued, running and completed agent workflows." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Workflows,
});

const pTone = { High: "danger", Medium: "warning", Low: "info" } as const;

function Workflows() {
  return (
    <>
      <PageHeader title="Workflows" subtitle="Queued → Running → Review → Done" />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {Object.entries(workflows).map(([col, items]) => (
          <div key={col} className="rounded-lg border border-border bg-secondary/40 p-3">
            <div className="mb-3 flex items-center justify-between px-1 text-sm font-medium">
              {col}<span className="text-xs text-muted-foreground">{items.length}</span>
            </div>
            <div className="space-y-3">
              {items.map((w) => (
                <Panel key={w.name} className="cursor-grab p-4">
                  <div className="text-sm font-medium">{w.name}</div>
                  <div className="mt-2 flex items-center gap-1.5 font-mono text-xs text-muted-foreground"><Bot className="h-3.5 w-3.5" />{w.agent}</div>
                  <div className="mt-3"><Pill tone={pTone[w.priority]}>{w.priority}</Pill></div>
                </Panel>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
